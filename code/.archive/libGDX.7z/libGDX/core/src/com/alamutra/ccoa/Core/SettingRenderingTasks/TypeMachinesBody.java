package com.alamutra.ccoa.Core.SettingRenderingTasks;

public enum TypeMachinesBody {
    SIMPLE_CAR,
    TEST_SQUARE_20,
    TRUCK,
    TANK,
    RACING_CAR,
    NIER_AUTOMATA_2B,
    TURTLE,
    STAR_DESTROYER,
    WALL_CAR,
    WALL_SQUARE
}
