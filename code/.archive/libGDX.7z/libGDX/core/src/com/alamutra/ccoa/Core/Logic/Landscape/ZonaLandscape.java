package com.alamutra.ccoa.Core.Logic.Landscape;

public interface ZonaLandscape {
}
