package com.alamutra.ccoa.Core.Logic;

public interface IndexLayer {
    public int getZIndex();
}
