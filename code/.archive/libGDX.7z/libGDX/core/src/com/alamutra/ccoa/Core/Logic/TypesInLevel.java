package com.alamutra.ccoa.Core.Logic;

public enum TypesInLevel {
    ENVIRONMENT,
    OBJECT
}
