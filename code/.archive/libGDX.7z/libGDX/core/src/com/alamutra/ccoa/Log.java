package com.alamutra.ccoa;

public class Log {
}
