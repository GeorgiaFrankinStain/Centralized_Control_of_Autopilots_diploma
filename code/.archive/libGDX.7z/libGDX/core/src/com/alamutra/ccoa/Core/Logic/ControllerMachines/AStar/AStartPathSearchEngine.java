package com.alamutra.ccoa.Core.Logic.ControllerMachines.AStar;

import com.alamutra.ccoa.Core.Logic.MovingBody.PathCCoA;

public interface AStartPathSearchEngine {
    public PathCCoA getPath();
}
