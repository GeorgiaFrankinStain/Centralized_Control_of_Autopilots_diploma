package com.alamutra.ccoa.Core.Logic.ControllerMachines.FabricNetworkNodes;

import com.alamutra.ccoa.Core.Logic.ControllerMachines.NetworkNodes;

public interface FabricNetworkNodes {
    public NetworkNodes getNewNetworkNodes();
}
