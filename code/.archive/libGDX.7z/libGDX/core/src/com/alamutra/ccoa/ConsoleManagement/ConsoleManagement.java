package com.alamutra.ccoa.ConsoleManagement;

public interface ConsoleManagement {
}
