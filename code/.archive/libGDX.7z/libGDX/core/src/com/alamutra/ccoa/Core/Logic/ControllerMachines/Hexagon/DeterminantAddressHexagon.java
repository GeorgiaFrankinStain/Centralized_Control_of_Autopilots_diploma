package com.alamutra.ccoa.Core.Logic.ControllerMachines.Hexagon;

import com.alamutra.ccoa.Core.Logic.FootprintSpaceTime.PointCCoA;

public interface DeterminantAddressHexagon {
    public PointCCoA detectedCenterHexagonIncludeCoordinate();

    public int detectedHashCodeHexagonIncludeCoordinate();
}
