package com.alamutra.ccoa.Core.Logic.ControllerMachines.Hexagon;

public interface DeterminantIsMultiple {
    public boolean isCoordinateIsMultiple();
}
