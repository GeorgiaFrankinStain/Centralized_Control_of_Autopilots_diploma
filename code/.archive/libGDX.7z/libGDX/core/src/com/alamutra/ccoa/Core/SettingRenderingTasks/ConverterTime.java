package com.alamutra.ccoa.Core.SettingRenderingTasks;

import com.alamutra.ccoa.Core.Logic.IndexLayer;

public interface ConverterTime {
    public double convert(double time, IndexLayer indexLayer);
}
