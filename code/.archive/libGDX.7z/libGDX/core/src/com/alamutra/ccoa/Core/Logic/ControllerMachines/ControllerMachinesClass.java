package com.alamutra.ccoa.Core.Logic.ControllerMachines;

public class ControllerMachinesClass {
}
