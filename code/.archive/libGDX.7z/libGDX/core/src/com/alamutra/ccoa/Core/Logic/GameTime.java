package com.alamutra.ccoa.Core.Logic;

public interface GameTime {
    public float getGameTime();

    public void addGameTime(float adding);
}
