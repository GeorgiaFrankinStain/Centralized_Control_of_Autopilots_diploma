package com.alamutra.ccoa.PercistanceDataAccessObjects;

import com.alamutra.ccoa.Core.Logic.FootprintSpaceTime.FootprintsSpaceTime;

public interface Order {
    public void mark(FootprintsSpaceTime footprintsSpaceTime);
}
