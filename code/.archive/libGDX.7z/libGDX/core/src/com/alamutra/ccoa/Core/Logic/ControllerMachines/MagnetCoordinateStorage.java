package com.alamutra.ccoa.Core.Logic.ControllerMachines;

public interface MagnetCoordinateStorage {
    public Node getFirstMagnetizedNodeTryAdd(Node tryAddingNode);
}
