package com.alamutra.ccoa.Core.Wrappers;

public interface RandomWrapper {
    public int nextInt();
}
