package com.alamutra.ccoa.Core.Wrappers;

public interface PairCCoA<K, V> {
    public K getKey();
    public V getValue();
}
