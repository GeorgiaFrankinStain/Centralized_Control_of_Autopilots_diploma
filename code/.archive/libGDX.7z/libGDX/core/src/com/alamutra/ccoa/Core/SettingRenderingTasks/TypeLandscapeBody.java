package com.alamutra.ccoa.Core.SettingRenderingTasks;

public enum TypeLandscapeBody {
    SWAMP,
    ASPHALT,
    WATER,
    GRASS,
    BUILDING
}
