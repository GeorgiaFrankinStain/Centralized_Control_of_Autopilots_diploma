package com.alamutra.ccoa.Core.Logic.ControllerMachines.Hexagon;

import com.alamutra.ccoa.Core.Logic.ControllerMachines.Node;

import java.util.List;

public interface DeterminantNeighborsNodes {
    public List<Node> neighboringMultipleNodes();
}
