package com.alamutra.ccoa.Core.SettingRenderingTasks;

public interface SubWindow {
}
