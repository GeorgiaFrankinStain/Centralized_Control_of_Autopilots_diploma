package com.alamutra.ccoa.Core.Logic.FootprintSpaceTime;

public interface NextFootprintAndTimes {
    public double getTimeOfKeyFootprint();

    public double getTimeOfNextFootprint();

    public Footprint getNextFootprint();
}
