package com.alamutra.ccoa.PercistanceDataAccessObjects.Exception;

public class NotEnoughDataException extends Exception {

    public NotEnoughDataException(String message) {
        super(message);
    }
}
