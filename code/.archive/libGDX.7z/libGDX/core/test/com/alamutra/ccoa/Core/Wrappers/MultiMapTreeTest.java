package com.alamutra.ccoa.Core.Wrappers;

import org.junit.jupiter.api.Test;

import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;

class MultiMapTreeTest {



    @Test
    public void iteratorEntryPair() {

    }

}